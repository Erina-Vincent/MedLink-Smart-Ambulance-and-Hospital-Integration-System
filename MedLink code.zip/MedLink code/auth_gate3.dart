
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

import '../hospital/hospitalhome.dart';
import '../hospital/hospitallog.dart';






void main() {
  runApp(new MaterialApp(
    home: new AuthGate3(),



  ));




}
class AuthGate3 extends StatelessWidget {
  const AuthGate3({super.key});

/*
String value='Text';
void Clickme(){

setState(() {
value='tutor';


});


}
*/
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context,snapshot){
          if(!snapshot.hasData) {
            return HospitalLogin();

          }
          return HospitalHome();
        }

    );

  }
}

