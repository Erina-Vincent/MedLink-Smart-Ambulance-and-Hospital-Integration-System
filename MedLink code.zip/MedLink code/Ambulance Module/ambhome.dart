import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'alerthospital.dart';
import 'amblog.dart';

void main() {
  runApp(const MaterialApp(
    home: AmbulanceHome(),
  ));
}

class AmbulanceHome extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const AmbulanceHome({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  State<AmbulanceHome> createState() => _AmbulanceHomeState();
}

class _AmbulanceHomeState extends State<AmbulanceHome> {
  int _selectedIndex = 0;
  bool isLogoutLoading = false;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomePage(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        ambkey: widget.ambkey,
      ),
      GetPatientDetails(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        ambkey: widget.ambkey,
      ),
      ShareLiveLocation(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        ambkey: widget.ambkey,



      ),
      NearByHospital(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        ambkey: widget.ambkey,


      ),


      Track(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        ambkey: widget.ambkey,


      ),
    ];
  }

  Future<void> logout() async {
    setState(() {
      isLogoutLoading = true;
    });

    await FirebaseAuth.instance.signOut();

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => AmbulanceLogin()),
      );
    }

    setState(() {
      isLogoutLoading = false;
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          'Ambulance Dashboard',
          style: TextStyle(color: Colors.indigo),
        ),
        actions: [
          IconButton(
            onPressed: isLogoutLoading ? null : logout,
            icon: isLogoutLoading
                ? const CircularProgressIndicator()
                : Icon(Icons.exit_to_app, color: Colors.indigo.shade700),
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.indigo,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'Patient Details',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Live Location',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_hospital),
            label: 'Hospitals',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.start),
            label: 'Track',
          ),
        ],
      ),


    );
  }
}

// Home Page
class HomePage extends StatelessWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const HomePage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/ambhome.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  'Welcome to the Ambulance Admin Dashboard',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Text(
                  'Patients are almost always preceded by their parents, because no matter how fast an ambulance can drive, terrified parents can drive faster',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class GetPatientDetails extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const GetPatientDetails({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  _AddPageState createState() => _AddPageState();
}

class _AddPageState extends State<GetPatientDetails> {
  final _formKey = GlobalKey<FormState>();
  final _database = FirebaseDatabase.instance.reference();
  bool isLoader = false;

  TextEditingController nameController = TextEditingController();
  TextEditingController contactController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController bloodController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  @override
  void initState() {
    super.initState();
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoader = true;
      });

      try {
        String userId = widget.ambkey ?? 'dummyUserId';

        Map<String, dynamic> userData = {
          'pname': nameController.text,
          'blood': bloodController.text,
          'pcontact': contactController.text,
          'plocation': locationController.text,
          'patientinfo': descriptionController.text,
          'ukey': userId,
          'status': 'request',
        };

        await _database.child('patientdetails').child(userId).set(userData);

        nameController.clear();
        contactController.clear();
        locationController.clear();
        bloodController.clear();
        descriptionController.clear();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Details Updated Successfully'),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => AmbulanceHome(
              email: widget.email,
              name: widget.name,
              location: widget.location,
              mobile: widget.mobile,
              ambkey: widget.ambkey,
            ),
          ),
        );
      } catch (e) {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Update Failed"),
              content: Text(e.toString()),
            );
          },
        );
      } finally {
        setState(() {
          isLoader = false;
        });
      }
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => AmbulanceHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          ambkey: widget.ambkey,
        ),
      ),
    );
    return Future.value(false);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: Container(
          width: double.infinity, // Full screen width
          height: double.infinity, // Full screen height
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.indigo.shade700, Colors.blue.shade400],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                      color: Colors.white.withOpacity(0.85),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            _buildTextFormField('Name', nameController),
                            _buildTextFormField('Blood Group', bloodController),
                            _buildTextFormField('Contact', contactController),
                            _buildTextFormField('Patient Emergency', descriptionController),
                            _buildTextFormField('Location', locationController),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    isLoader
                        ? Center(child: CircularProgressIndicator())
                        : _buildButton('Submit', _submitForm),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.indigo.shade700),
          hintText: 'Enter $label',
          hintStyle: TextStyle(color: Colors.grey),
          filled: true,
          fillColor: Colors.white,
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.indigo.shade700, width: 2.0),
            borderRadius: BorderRadius.circular(20),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.indigo.shade700, width: 1.5),
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
      ),
    );
  }

  Widget _buildButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(vertical: 15),
        primary: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        elevation: 5,
      ),
    );
  }
}



class ShareLiveLocation extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const ShareLiveLocation({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  _ShareLiveLocationState createState() => _ShareLiveLocationState();
}

class _ShareLiveLocationState extends State<ShareLiveLocation> {
  bool isLocationSharing = false; // To track if location sharing is on or off
  Position? _currentLocation;
  Timer? _locationTimer;
  final DatabaseReference _databaseRef = FirebaseDatabase.instance.reference();

  @override
  void dispose() {
    _locationTimer?.cancel();  // Make sure to cancel the timer when the widget is disposed
    super.dispose();
  }

  // Method to start location updates every 10 seconds
  void _startLocationSharing() {
    setState(() {
      isLocationSharing = true;
    });

    // Start the timer to update location every 10 seconds
    _locationTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _getCurrentLocation();
    });
  }

  // Method to stop location updates
  void _stopLocationSharing() {
    setState(() {
      isLocationSharing = false;
    });

    // Cancel the location update timer
    _locationTimer?.cancel();
  }

  // Method to get the current location
  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled, ask the user to enable it
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      // Request location permission if not granted
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse &&
          permission != LocationPermission.always) {
        // Permission denied, handle it accordingly
        return;
      }
    }

    // Get the current location
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      _currentLocation = position;
    });

    // Store the location data in Firebase Realtime Database
    _storeLocationInFirebase(position);
  }

  // Method to store location data in Firebase Realtime Database
  void _storeLocationInFirebase(Position position) {
    String uid = widget.ambkey ?? "default";  // You can replace this with the user's unique ID
    String timestamp = DateTime.now().toIso8601String();

    // Store the location data under a path with the user's ID and timestamp
    _databaseRef.child("locations/$uid").set({
      'latitude': position.latitude,
      'longitude': position.longitude,
      'timestamp': timestamp,
      'status': 'updated',
      'ambkey': uid,
    }).then((_) {
      print("Location data saved to Firebase!");
    }).catchError((error) {
      print("Error saving location data to Firebase: $error");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.indigo.shade700, Colors.blue.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_currentLocation != null)
                  Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    color: Colors.white.withOpacity(0.9),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          Text(
                            'Current Location:',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'Lat: ${_currentLocation!.latitude}\nLong: ${_currentLocation!.longitude}',
                            style: TextStyle(fontSize: 18),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: isLocationSharing
                      ? _stopLocationSharing
                      : _startLocationSharing,
                  child: Text(
                    isLocationSharing
                        ? 'Stop Sharing Location'
                        : 'Start Sharing Location',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                    primary: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    elevation: 10,
                  ),
                ),
                const SizedBox(height: 20),
                if (isLocationSharing)
                  CircularProgressIndicator(
                    color: Colors.deepPurpleAccent,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Near By Hospital Page
class NearByHospital extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const NearByHospital({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  _MyHomePageeegState createState() => _MyHomePageeegState();
}

class _MyHomePageeegState extends State<NearByHospital> {
  String authh = " ";
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref().child('hospital');
  Position? _currentPosition;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation().then((position) {
      setState(() {
        _currentPosition = position;
      });
    });
    final FirebaseAuth _auth = FirebaseAuth.instance;
    User? user = _auth.currentUser;
    authh = user?.uid ?? " ";
  }

  Future<Position> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    // Check location permissions
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // Get current location
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DatabaseEvent>(
      stream: _databaseReference.onValue,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error loading requests.'));
        } else if (!snapshot.hasData || snapshot.data?.snapshot.value == null) {
          return Center(child: Text('No accepted requests available.'));
        } else {
          Map<dynamic, dynamic> data = snapshot.data!.snapshot.value as Map<dynamic, dynamic>;
          List<Map<String, dynamic>> doctorsList = data.entries.map((entry) {
            return {
              'id': entry.key,
              ...Map<String, dynamic>.from(entry.value),
            };
          }).toList();

          // Calculate distance and sort the list
          if (_currentPosition != null) {
            doctorsList.sort((a, b) {
              double distanceA = Geolocator.distanceBetween(
                _currentPosition!.latitude,
                _currentPosition!.longitude,
                double.parse(a['latitude'] ?? '0'),
                double.parse(a['longitude'] ?? '0'),
              );
              double distanceB = Geolocator.distanceBetween(
                _currentPosition!.latitude,
                _currentPosition!.longitude,
                double.parse(b['latitude'] ?? '0'),
                double.parse(b['longitude'] ?? '0'),
              );
              return distanceA.compareTo(distanceB);
            });
          }

          return ListView.builder(
            itemCount: doctorsList.length,
            itemBuilder: (context, index) {
              var doctor = doctorsList[index];

              return Card(
                elevation: 8,
                margin: EdgeInsets.all(15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              doctor['name'] ?? 'Hospital Name',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 22,
                                color: Colors.blueAccent,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.directions,
                              color: Colors.green,
                              size: 30,
                            ),
                            onPressed: () {
                              _openMap(doctor['latitude'], doctor['longitude']);
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      Text(
                        'E-Mail: ${doctor['email'] ?? 'N/A'}',
                        style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                      ),
                      Text(
                        'Contact Number: ${doctor['mobile'] ?? 'N/A'}',
                        style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                      ),

                      Text(
                        'Location: ${doctor['location'] ?? 'N/A'}',
                        style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                      ),
                      SizedBox(height: 15),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AlertHospital(
                                  hospitalEmail: doctor['email'],
                                  hospitalName: doctor['name'],
                                  hospitalMobile: doctor['mobile'],
                                  hospitalLocation: doctor['location'],
                                  hoskey : doctor['hoskey'],
                                  ambname: widget.name,
                                  ambemail: widget.email,
                                  ambmobile: widget.mobile,
                                  ambkey: widget.ambkey,
                                  location: widget.location,



                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text('Emergency Alert'),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        }
      },
    );
  }

  void _openMap(String? latitude, String? longitude) async {
    if (latitude != null && longitude != null) {
      String googleUrl = 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
      if (await canLaunch(googleUrl)) {
        await launch(googleUrl);
      } else {
        throw 'Could not open map.';
      }
    }
  }



}



class Track extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? ambkey;

  const Track({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.ambkey,
  }) : super(key: key);

  @override
  _MyTrackState createState() => _MyTrackState();
}

class _MyTrackState extends State<Track> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('EmergencyAlerts');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('ambkey')
          .equalTo(widget.ambkey)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'confirmed')
              .map((entry) {
            return {
              'key': entry.key,
              'key': entry.key,
              'ambname': entry.value['ambname'],
              'ambemail': entry.value['ambemail'],
              'ambmobile': entry.value['ambmobile'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => AmbulanceHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          ambkey: widget.ambkey,
        ),
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.person, size: 40, color: Colors.blue[700]),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['ambname']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['ambemail']}',
                                style:
                                TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['ambmobile']}',
                                style:
                                TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                             /* SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: TextStyle(fontSize: 14, color: Colors.black54),
                              ),*/
                              SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
