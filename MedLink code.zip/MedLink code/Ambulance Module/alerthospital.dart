import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/ambulance/ambhome.dart';

class AlertHospital extends StatefulWidget {
  final String? ambname;
  final String? ambemail;
  final String? ambmobile;
  final String? ambkey;
  final String? location;
  final String? hoskey;
  final String? hospitalName;
  final String? hospitalEmail;
  final String? hospitalMobile;
  final String? hospitalLocation;

  const AlertHospital({
    Key? key,
    this.ambname,
    this.ambemail,
    this.ambmobile,
    this.location,
    this.ambkey,
    this.hoskey,
    this.hospitalName,
    this.hospitalEmail,
    this.hospitalMobile,
    this.hospitalLocation,
  }) : super(key: key);

  @override
  _AlertHospitalState createState() => _AlertHospitalState();
}

class _AlertHospitalState extends State<AlertHospital> {
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('EmergencyAlerts');

  Future<void> _bookAppointment() async {
    try {
      await _appointmentsRef.push().set({
        'ambname': widget.ambname,
        'ambemail': widget.ambemail,
        'ambmobile': widget.ambmobile,
        'ambkey': widget.ambkey,
        'hoskey': widget.hoskey,
        'hospitalName': widget.hospitalName,
        'emergencyTime': DateTime.now().toIso8601String(),
        'status': 'request',
        'hospitalEmail': widget.hospitalEmail,
        'hospitalMobile': widget.hospitalMobile,
        'hospitalLocation': widget.hospitalLocation,
      });

      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Emergency Request Accepted'),
          content: Text(
              'Your Emergency request has been forwarded to ${widget.hospitalName}.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AmbulanceHome(
                      name: widget.ambname,
                      email: widget.ambemail,
                      location: widget.location,
                      mobile: widget.ambmobile,
                      ambkey: widget.ambkey,
                    ),
                  ),
                );
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error Forwarding Emergency Requ: $error'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Confirm To Share'),
        backgroundColor: Colors.blue[800],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[50]!, Colors.blue[200]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
              elevation: 8,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundImage: AssetImage(
                        'assets/images/doctor_placeholder.png',
                      ), // Replace with actual image
                      onBackgroundImageError: (_, __) {
                        // Fallback in case the image is not found
                        debugPrint('Failed to load image.');
                      },
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hospital Name: ${widget.hospitalName}',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[900],
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Contact Number: ${widget.hospitalMobile}',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey[600],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: _bookAppointment,
                icon: Icon(Icons.check, color: Colors.blue[900]),
                label: const Text(
                  'Confirm To Share',
                  style: TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  padding:
                  const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
