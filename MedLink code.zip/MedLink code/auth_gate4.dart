/*

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:patientmonitor/ambulance/amblog.dart';
import '../ambulance/ambhome.dart';
import '../doctor/doctorhome.dart';
import '../doctor/doctorlog.dart';
import '../patient/uslogin.dart';
import '../patient/welcomescre.dart';





void main() {
  runApp(new MaterialApp(
    home: new AuthGate4(),



  ));




}
class AuthGate4 extends StatelessWidget {
  const AuthGate4({super.key});

*/
/*
String value='Text';
void Clickme(){

setState(() {
value='tutor';


});


}
*//*

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context,snapshot){
          if(!snapshot.hasData) {
            return PatientLogin();

          }

          else{
            User? user = snapshot.data;
            String uid = user?.uid ?? ''; // You can use the UID as ne

            DatabaseReference databaseReference = FirebaseDatabase.instance.reference().child('patient').child(uid);

            // Use the onValue stream to listen for changes
            databaseReference.onValue.listen((event) {
              print('Database event received: $event');

              // Check if the event contains the data you need
              if (event.snapshot != null && event.snapshot.value != null) {
                var userData = event.snapshot.value;
                print('User data from database: $userData');

                // Check if userData is a Map
                if (userData is Map<Object?, Object?>) {
                  // Cast the map to Map<String, dynamic>
                  Map<String, dynamic> userDataMap = userData.cast<String, dynamic>();

                  // Access email directly and handle null case

                  String? name = userDataMap['name'];
                  String? email = userDataMap['email'];
                  String? mobile = userDataMap['mobile'];
                  String? location = userDataMap['location'];
                  String? pkey = userDataMap['pkey'];



                  if (email != null) {
                    print('Email from database: $email');

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Login Successfully')),
                    );

                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => PatientHome(

                            name: name,
                            email: email,

                            mobile:mobile,

                            pkey: pkey,

                        ))
                    );
                  } else {
                    print('Email key is null or not found in userData.');
                  }
                } else {
                  print('Invalid data structure in the database.');
                  print('Type of userData: ${userData.runtimeType}');
                  print('Content of userData: $userData');
                }
              }
            });


          }

          return PatientHome(

          );
        }

    );

  }
}








*/

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';


import '../patient/uslogin.dart';
import '../patient/welcomescre.dart';




void main() {
  runApp(MaterialApp(
    home: AuthGate4(),
  ));
}

class AuthGate4 extends StatelessWidget {
  const AuthGate4({super.key});

  Future<Map<String, dynamic>?> _getUserData(String uid) async {
    DatabaseReference databaseReference =
    FirebaseDatabase.instance.ref().child('patient').child(uid);
    DataSnapshot snapshot = await databaseReference.get();
    if (snapshot.value != null && snapshot.value is Map) {
      return Map<String, dynamic>.from(snapshot.value as Map);
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return PatientLogin();
        } else {
          User? user = snapshot.data;
          String uid = user?.uid ?? '';

          return FutureBuilder<Map<String, dynamic>?>(
            future: _getUserData(uid),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error loading user data'));
              } else if (!snapshot.hasData || snapshot.data == null) {
                return Center(child: Text('No user data found'));
              } else {
                Map<String, dynamic>? userData = snapshot.data;
                if (userData != null) {
                  String? email = userData['email'];
                  String? name = userData['name'];
                  String? mobile = userData['mobile'];

                  String? pkey = userData['pkey'];

                  // Navigate to UserHome after the data is processed
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    // Use Navigator.pushReplacement to navigate to Home page
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PatientHome(
                          email: email,
                          name: name,
                          mobile: mobile,

                          pkey: pkey,
                        ),
                      ),
                    );
                  });

                  return Scaffold(
                    body: Center(
                      child: CircularProgressIndicator(), // While navigating
                    ),
                  );
                } else {
                  return Center(child: Text('Error: User data is null'));
                }
              }
            },
          );
        }
      },
    );
  }
}

