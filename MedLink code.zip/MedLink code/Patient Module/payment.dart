import 'package:flutter/material.dart';
import 'dart:async';

import 'package:patientmonitor/patient/welcomescre.dart';

class PaymentPage extends StatelessWidget {
  final String appointmentKey;
  final String paymentAmount;

  const PaymentPage({
    Key? key,
    required this.appointmentKey,
    required this.paymentAmount,
  }) : super(key: key);

  void _showPaymentConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Payment Successful'),
          content: Text('Thank you! Your payment of \ Rs.${paymentAmount} has been completed.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );

    // Redirect to the patient's home page after 5 seconds
    Timer(Duration(seconds: 5), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => PatientHome(

          ),
        ),
      );; // Adjust route name as needed
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Total Amount to Pay',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                '\ Rs.${paymentAmount}',
                style: TextStyle(fontSize: 32, color: Colors.green, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 30),
              Text(
                'Appointment ID: $appointmentKey',
                style: TextStyle(fontSize: 16, color: Colors.grey[700]),
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed: () => _showPaymentConfirmation(context),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                child: Text(
                  'Pay',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
