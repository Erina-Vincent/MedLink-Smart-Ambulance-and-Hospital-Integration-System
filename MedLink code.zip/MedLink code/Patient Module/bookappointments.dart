import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/welcomescre.dart';

class BookAppointment extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;
  final String? doctorKey; // Key of the selected doctor
  final String? doctorName;
  final String? doctorfee;// Name of the selected doctor
  final String? specialist;

  const BookAppointment({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
    this.doctorKey,
    this.doctorName,
    this.doctorfee,
    this.specialist,

  }) : super(key: key);

  @override
  _BookAppointmentState createState() => _BookAppointmentState();
}

class _BookAppointmentState extends State<BookAppointment> {
  final TextEditingController _timeController = TextEditingController();
  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('appointments');

  Future<void> _bookAppointment() async {
    if (_timeController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please select a time for the appointment')),
      );
      return;
    }

    await _appointmentsRef.push().set({
      'doctorKey': widget.doctorKey,
      'uKey': widget.pkey,
      'doctorName': widget.doctorName,
      'patientName': widget.name,
      'patientEmail': widget.email,
      'patientMobile': widget.mobile,
      'appointmentTime': _timeController.text,
      'status': 'request',
      'payment': widget.doctorfee,
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Appointment Confirmed'),
        content: Text(
            'Your appointment with Dr. ${widget.doctorName} is confirmed at ${_timeController.text}.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => PatientHome(
                    email: widget.email,
                    name: widget.name,
                    mobile: widget.mobile,
                    pkey: widget.pkey,
                  ),
                ),
              );
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Book Appointment'),
        backgroundColor: Colors.blue[800],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[50]!, Colors.blue[200]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
              elevation: 8,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundImage: AssetImage('assets/images/doctor_placeholder.png'), // Replace with actual image
                    ),
                    SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Dr. ${widget.doctorName}',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[900],
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Specialist: ${widget.specialist}',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Select Appointment Time',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.blue[900],
              ),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _timeController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                labelText: 'Appointment Time',
                hintText: 'Enter appointment time (e.g., 10:00 AM)',
                labelStyle: TextStyle(
                  color: Colors.blue[800],
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue[800]!, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue[900]!, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              cursorColor: Colors.blue[900],
            ),
            SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: _bookAppointment,
                icon: Icon(Icons.check, color: Colors.white),
                label: Text(
                  'Confirm Appointment',
                  style: TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                  backgroundColor: Colors.lightBlue[900],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: Text(
                '*You will receive an email confirmation*',
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: Colors.grey[600],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
