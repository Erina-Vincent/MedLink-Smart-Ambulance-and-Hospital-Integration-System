import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/welcomescre.dart';

class BuyMedicine extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;
  final String? doctorKey; // Key of the selected doctor
  final String? doctorName;
  final String? doctorfee; // Doctor's fee
  final String? specialist;

  const BuyMedicine({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
    this.doctorKey,
    this.doctorName,
    this.doctorfee,
    this.specialist,
  }) : super(key: key);

  @override
  _BuyMedicineState createState() => _BuyMedicineState();
}

class _BuyMedicineState extends State<BuyMedicine> {
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _medicineController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();

  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('medicine');

  Future<void> _bookAppointment() async {
    if (
        _medicineController.text.isEmpty ||
        _quantityController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill all the details')),
      );
      return;
    }

    await _appointmentsRef.push().set({
      'doctorKey': widget.doctorKey,
      'uKey': widget.pkey,
      'doctorName': widget.doctorName,
      'patientName': widget.name,
      'patientEmail': widget.email,
      'patientMobile': widget.mobile,
      'appointmentTime': _timeController.text,
      'medicineName': _medicineController.text,
      'quantity': _quantityController.text,
      'status': 'request',
      'payment': widget.doctorfee,
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Order Confirmed'),
        content: Text(
          'Your order for ${_medicineController.text} (${_quantityController.text}) is placed.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => PatientHome(
                    email: widget.email,
                    name: widget.name,
                    mobile: widget.mobile,
                    pkey: widget.pkey,
                  ),
                ),
              );
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Buy Medicine'),
        backgroundColor: Colors.blue[800],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[50]!, Colors.blue[200]!],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
              elevation: 8,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundImage: AssetImage('assets/images/doctor_placeholder.png'), // Replace with actual image
                    ),
                    SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pharmacy: ${widget.doctorName ?? "Not available"}',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Contact: ${widget.specialist ?? "N/A"}',
                          style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
           

            SizedBox(height: 20),
            Text(
              'Enter Medicine Details',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.blue[900],
              ),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _medicineController,
              decoration: _buildInputDecoration('Medicine Name', 'Enter medicine name'),
              cursorColor: Colors.blue[900],
            ),
            SizedBox(height: 12),
            TextField(
              controller: _quantityController,
              keyboardType: TextInputType.number,
              decoration: _buildInputDecoration('Quantity', 'Enter quantity (e.g., 2)'),
              cursorColor: Colors.blue[900],
            ),
            SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                onPressed: _bookAppointment,
                icon: Icon(Icons.shopping_cart, color: Colors.white),
                label: Text(
                  'Confirm Order',
                  style: TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                  backgroundColor: Colors.lightBlue[900],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
               ],
        ),
      ),
    );
  }

  InputDecoration _buildInputDecoration(String label, String hint) {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white,
      labelText: label,
      hintText: hint,
      labelStyle: TextStyle(color: Colors.blue[800]),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.blue[800]!, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.blue[900]!, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }
}
