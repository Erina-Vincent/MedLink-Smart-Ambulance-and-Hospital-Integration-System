import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:async';

import 'welcomescre.dart'; // Your patient home screen
import 'bookappointments.dart'; // The appointment booking screen

class DoctorListView extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;

  const DoctorListView({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  _DoctorListViewState createState() => _DoctorListViewState();
}

class _DoctorListViewState extends State<DoctorListView> {
  late StreamController<DatabaseEvent> _doctorStreamController;
  final DatabaseReference _doctorsRef = FirebaseDatabase.instance.ref('doctorinfo');
  String selectedFilter = 'hospital'; // Default filter
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    _doctorStreamController = StreamController<DatabaseEvent>();
    _doctorsRef.onValue.listen((event) {
      _doctorStreamController.add(event);
    });
  }

  @override
  void dispose() {
    _doctorStreamController.close();
    super.dispose();
  }

  Widget _buildDoctorListView() {
    return StreamBuilder<DatabaseEvent>(
      stream: _doctorStreamController.stream,
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data?.snapshot.value != null) {
          Map<String, dynamic> data = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
          List<Map<String, dynamic>> filteredDoctors = data.entries
              .map((entry) => Map<String, dynamic>.from(entry.value))
              .where((doctor) {
            if (searchQuery.isNotEmpty) {
              if (selectedFilter == 'hospital') {
                return doctor['hospital']
                    ?.toString()
                    .toLowerCase()
                    .contains(searchQuery.toLowerCase()) ??
                    false;
              } else if (selectedFilter == 'specialist') {
                return doctor['specialist']
                    ?.toString()
                    .toLowerCase()
                    .contains(searchQuery.toLowerCase()) ??
                    false;
              }
            }
            return true;
          }).toList();

          if (filteredDoctors.isEmpty) {
            return Center(
              child: Text(
                'No doctors found',
                style: TextStyle(
                  color: Colors.purple[800],
                  fontSize: 16,
                ),
              ),
            );
          }

          return Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/book.jpg',
                  fit: BoxFit.cover,
                  color: Colors.purple.withOpacity(0.1),
                  colorBlendMode: BlendMode.lighten,
                ),
              ),
              ListView.builder(
                itemCount: filteredDoctors.length,
                itemBuilder: (context, index) {
                  final doctor = filteredDoctors[index];
                  final String dockey = doctor['ukey'] ?? '';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0),
                    ),
                    margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    elevation: 6,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16.0),
                        gradient: LinearGradient(
                          colors: [Colors.purple[400]!, Colors.deepPurpleAccent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: ListTile(
                        leading: doctor['photoUrl'] != null
                            ? CircleAvatar(
                          backgroundImage: NetworkImage(doctor['photoUrl']),
                          radius: 40,
                        )
                            : Icon(
                          Icons.medical_services,
                          size: 50,
                          color: Colors.white,
                        ),
                        title: Text(
                          '${doctor['name'] ?? 'Unknown'} - ${doctor['specialist'] ?? 'Unknown'}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Hospital: ${doctor['hospital'] ?? 'Unknown'}',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,
                              ),
                            ),
                            Text(
                              'E-mail: ${doctor['email'] ?? 'Unknown'}',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,
                              ),
                            ),
                            Text(
                              'Contact: ${doctor['contact'] ?? 'Unknown'}',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,
                              ),
                            ),
                            SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BookAppointment(
                                      email: widget.email,
                                      name: widget.name,
                                      mobile: widget.mobile,
                                      pkey: widget.pkey,
                                      doctorKey: dockey,
                                      doctorName: doctor['name'],
                                      doctorfee: doctor['fees'],
                                      specialist: doctor['specialist'],
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepPurple[800],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text('Book Appointment'),
                            ),
                          ],
                        ),
                        isThreeLine: true,
                      ),
                    ),
                  );
                },
              ),
            ],
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error: ${snapshot.error}',
              style: TextStyle(color: Colors.red),
            ),
          );
        } else {
          return Center(child: CircularProgressIndicator());
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => PatientHome(
              email: widget.email,
              name: widget.name,
              mobile: widget.mobile,
              pkey: widget.pkey,
            ),
          ),
        );
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepPurple[800],
          title: Center(
            child: Text(
              'Doctors List',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: DropdownButton<String>(
                      value: selectedFilter,
                      items: [
                        DropdownMenuItem(value: 'hospital', child: Text('Hospital')),
                        DropdownMenuItem(value: 'specialist', child: Text('Specialist')),
                      ],
                      onChanged: (value) {
                        setState(() {
                          selectedFilter = value!;
                        });
                      },
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: 'Enter $selectedFilter',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                      onChanged: (value) {
                        setState(() {
                          searchQuery = value;
                        });
                      },
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildDoctorListView()),
          ],
        ),
      ),
    );
  }
}
