import 'package:flutter/material.dart';
import 'package:patientmonitor/main.dart';
import 'package:patientmonitor/patient/usreg.dart';
import 'package:patientmonitor/patient/welcomescre.dart';
import '../services/auth_services.dart';
import '../utils/appvalidator.dart';

class PatientLogin extends StatefulWidget {
  PatientLogin({Key? key}) : super(key: key);

  @override
  _ConLoginPageState createState() => _ConLoginPageState();
}

class _ConLoginPageState extends State<PatientLogin> {
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final TextEditingController emailcontroller = TextEditingController();
  final TextEditingController passwordcontroller = TextEditingController();
  var isLoader = false;
  var authservice = AuthService();
  var appvalidator = AppValidator();

  Future<void> _submitform() async {
    setState(() {
      isLoader = true;
    });

    var data = {
      "email": emailcontroller.text,
      "password": passwordcontroller.text,
    };

    try {
      await authservice.patientLogin(data, context);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => PatientHome()),
      );
    } catch (e) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text("Login Failed"),
            content: Text(e.toString()),
            actions: <Widget>[
              TextButton(
                child: Text("OK"),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } finally {
      setState(() {
        isLoader = false;
      });
    }
  }

  InputDecoration _buildInputdecoration(String label, IconData icon) {
    return InputDecoration(
      fillColor: Colors.white.withOpacity(0.1),
      hintText: label,
      filled: true,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(25.0),
        borderSide: BorderSide(color: Colors.redAccent, width: 1.5),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(25.0),
        borderSide: BorderSide(color: Colors.white, width: 2.0),
      ),
      hintStyle: TextStyle(color: Colors.white70),
      suffixIcon: Icon(icon, color: Colors.white),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => SplashScreen()),
        );
        return false;
      },
      child: Scaffold(
        backgroundColor: Color(0xFF00293C), // Ambulance-themed dark blue
        body: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      Color(0xFF005D76), // Ambulance green
                      Color(0xFF003B44), // Ambulance blue
                    ],
                  ),
                ),
              ),
            ),
            Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.medical_services_outlined,
                      color: Colors.white,
                      size: 100,
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Patient Login',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 40),
                    Form(
                      key: _formkey,
                      child: Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            child: TextFormField(
                              controller: emailcontroller,
                              style: TextStyle(color: Colors.white),
                              cursorColor: Colors.white,
                              keyboardType: TextInputType.emailAddress,
                              autovalidateMode: AutovalidateMode
                                  .onUserInteraction,
                              decoration: _buildInputdecoration(
                                  "Email", Icons.email_outlined),
                              validator: appvalidator.validateEmail,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            child: TextFormField(
                              controller: passwordcontroller,
                              style: TextStyle(color: Colors.white),
                              cursorColor: Colors.white,
                              keyboardType: TextInputType.visiblePassword,
                              autovalidateMode: AutovalidateMode
                                  .onUserInteraction,
                              decoration: _buildInputdecoration(
                                  "Password", Icons.lock_outline),
                              validator: appvalidator.validatepassword,
                              obscureText: true,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    SizedBox(
                      height: 55.0,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: isLoader ? null : _submitform,
                        child: isLoader
                            ? Center(
                            child: CircularProgressIndicator(
                              color: Colors.white,
                            ))
                            : Text(
                          'Login',
                          style: TextStyle(fontSize: 18, color: Colors.white),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Or, continue with',
                      style: TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PatientRegistration(),
                              ),
                            );
                          },
                          child: Text(
                            'Register now',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
