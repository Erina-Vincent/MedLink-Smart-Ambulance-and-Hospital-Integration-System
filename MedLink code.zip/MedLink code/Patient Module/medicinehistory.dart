import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/payment.dart';
import 'package:patientmonitor/patient/pchat.dart';
import 'package:patientmonitor/patient/welcomescre.dart';
// Import the chat page

class MedicineHistory extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;

  const MedicineHistory({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MedicineHistory> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('medicine');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    _appointmentsRef
        .orderByChild('uKey')
        .equalTo(widget.pkey) // Query appointments by the user's key
        .once()
        .then((DatabaseEvent snapshot) {
      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;
        setState(() {
          _appointments = data.entries.map((entry) {
            return {
              'key': entry.key,
              'doctorName': entry.value['doctorName'],
              'appointmentTime': entry.value['appointmentTime'],
              'payment': entry.value['payment'],
              'status': entry.value['status'],
              'doctorKey': entry.value['doctorKey'], // Add doctorKey here
            };
          }).toList();
        });
      }
    });
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => PatientHome(
          email: widget.email,
          name: widget.name,
          mobile: widget.mobile,
          pkey: widget.pkey,
        ),
      ),
    );
    return true;
  }

  void _navigateToPayment(String appointmentKey, String payment) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PaymentPage(
          appointmentKey: appointmentKey,
          paymentAmount: payment,
        ),
      ),
    );
  }

  void _navigateToChat(String doctorKey) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PatientChatPage(
          pkey: widget.pkey,
          dockey: doctorKey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: Text('My Medicine Bookings'),
          backgroundColor: Colors.indigo,
          elevation: 0,
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.indigo, Colors.blueAccent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: _appointments.isEmpty
              ? Center(
            child: Text(
              'No Medicine Bookings found.',
              style: TextStyle(
                fontSize: 18,
                color: Colors.white.withOpacity(0.8),
              ),
            ),
          )
              : ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: _appointments.length,
            itemBuilder: (context, index) {
              final appointment = _appointments[index];
              return Card(
                color: Colors.white.withOpacity(0.9),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                elevation: 6,
                margin: const EdgeInsets.only(bottom: 16.0),
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 24,
                  ),
                  leading: Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.blueAccent,
                    ),
                    child: Icon(
                      Icons.event_available,
                      size: 30,
                      color: Colors.white,
                    ),
                  ),
                  title: Text(
                    'Dr. ${appointment['doctorName']}',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo[900],
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 8),
                      Text(
                        'Time: ${appointment['appointmentTime']}',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Payment: ${appointment['payment']}',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Status: ${appointment['status']}',
                        style: TextStyle(
                          fontSize: 14,
                          color: appointment['status'] == 'confirmed'
                              ? Colors.green
                              : Colors.orange,
                        ),
                      ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (appointment['status'] == 'confirmed')
                        IconButton(
                          icon: Icon(Icons.payment, color: Colors.green),
                          onPressed: () {
                            _navigateToPayment(
                              appointment['key'],
                              appointment['payment'],
                            );
                          },
                        ),
                      IconButton(
                        icon: Icon(Icons.chat, color: Colors.blue),
                        onPressed: () {
                          _navigateToChat(appointment['doctorKey']);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
