import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/welcomescre.dart';

class MonitorRecord extends StatefulWidget {
  final String? email;
  final String? name;
  final String? mobile;
  final String? pkey;

  const MonitorRecord({
    Key? key,
    this.email,
    this.name,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  _MonitorRecordState createState() => _MonitorRecordState();
}

class _MonitorRecordState extends State<MonitorRecord> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  bool _isLoading = false;

  final DatabaseReference _dbRef =
  FirebaseDatabase.instance.ref().child('healthcare_documents');
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<void> _uploadDocument() async {
    if (_titleController.text.isEmpty || _descriptionController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      String fileName =
          '${DateTime.now().millisecondsSinceEpoch}_${_titleController.text}';

      await _dbRef.push().set({
        'title': _titleController.text,
        'description': _descriptionController.text,
        'uploadedBy': widget.email,
        'uKey': widget.pkey,
        'timestamp': DateTime.now().toIso8601String(),
        'status': 'uploaded',
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Document uploaded successfully')),
      );

      if (context.mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => PatientHome(
              email: widget.email,
              name: widget.name,
              mobile: widget.mobile,
              pkey: widget.pkey,
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => PatientHome(
          email: widget.email,
          name: widget.name,
          mobile: widget.mobile,
          pkey: widget.pkey,
        ),
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final primaryColor = Colors.lightBlue[900];
    final accentColor = Colors.blue.shade400;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Upload Healthcare Document'),
          backgroundColor: primaryColor,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Document Title',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _isLoading ? null : _uploadDocument,
                icon: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Icon(Icons.cloud_upload),
                label: const Text('Upload'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
