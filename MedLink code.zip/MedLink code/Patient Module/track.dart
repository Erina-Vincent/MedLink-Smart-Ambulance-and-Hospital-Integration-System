import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/welcomescre.dart';
import 'ambtrack.dart';

class TrackAmbulance extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;

  const TrackAmbulance({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  _TrackAmbulanceState createState() => _TrackAmbulanceState();
}

class _TrackAmbulanceState extends State<TrackAmbulance> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('patientdetails');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();

    print(widget.mobile);
  }

  Future<void> _fetchAppointments() async {
    try {
      // Query to get appointments by mobile (pcontact)
      final snapshot = await _appointmentsRef
          .orderByChild('pcontact')
          .equalTo(widget.mobile)
          .once();

      print('Snapshot value: ${snapshot.snapshot.value}');


      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'request')
              .map((entry) {
            return {
              'key': entry.key,
              'mobile': entry.value['mobile'] ?? 'Unknown',
              'ukey': entry.value['ukey'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching locations: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => PatientHome(
          email: widget.email,
          name: widget.name,
          mobile: widget.mobile,
          pkey: widget.pkey,
        ),
      ),
    );
    return true;
  }

  void _navigateToChat(String? ukey) {
    if (ukey != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => TrackLocation(
            ukey: ukey,
          ),
        ),
      );
    } else {
      _showErrorDialog('Patient key is missing.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Track Ambulance'),
        ),
        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No location found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.location_on),
                          color: Colors.teal,
                          onPressed: () => _navigateToChat(appointment['ukey']),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
