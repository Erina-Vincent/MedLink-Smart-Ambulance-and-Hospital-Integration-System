import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:patientmonitor/patient/track.dart';
import 'package:patientmonitor/patient/uslogin.dart';
import 'package:patientmonitor/patient/viewpharmacy.dart';
import 'booking.dart';

import 'meicinehistory.dart';
import 'monitorrecord.dart';
import 'myappointments.dart';
import 'myhealthdocuments.dart';

void main() {
  runApp(MaterialApp(
    home: PatientHome(),
  ));
}

class PatientHome extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;

  const PatientHome({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  State<PatientHome> createState() => _HomeState();
}

class _HomeState extends State<PatientHome> {
  var isLogoutLoading = false;

  void logout() async {
    setState(() {
      isLogoutLoading = true;
    });

    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => PatientLogin()));

    setState(() {
      isLogoutLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue[800],
        title: Center(
          child: Text(
            'Patient Dashboard',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 22,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: logout,
            icon: isLogoutLoading
                ? CircularProgressIndicator(
              color: Colors.white,
            )
                : Icon(Icons.logout),
            color: Colors.redAccent,
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.lightBlue[100]!, Colors.lightGreen[100]!],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              UserAccountsDrawerHeader(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.lightBlue[700]!, Colors.green[700]!],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.local_hospital,
                    size: 48,
                    color: Colors.lightBlue[800],
                  ),
                ),
                accountName: Text(
                  widget.name ?? 'Guest User',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                  ),
                ),
                accountEmail: Text(
                  widget.email ?? 'guest@example.com',
                  style: TextStyle(
                    color: Colors.white70,
                  ),
                ),
              ),
              DrawerMenuItem(
                icon: Icons.home,
                title: 'Home',
                onTap: () => _navigateTo(PatientHome(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.access_time,
                title: 'Book Appointment',
                onTap: () => _navigateTo(DoctorListView(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.calendar_today,
                title: 'My Appointment Schedule',
                onTap: () => _navigateTo(MyAppointments(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.monitor_heart,
                title: 'Health Care Documents',
                onTap: () => _navigateTo(MonitorRecord(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.file_download,
                title: 'My Documents',
                onTap: () => _navigateTo(HealthcareDocumentsPage(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.view_column_outlined,
                title: 'View Pharmacy',
                onTap: () => _navigateTo(ViewPharmacy(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),
              DrawerMenuItem(
                icon: Icons.medication_outlined,
                title: 'Medicines',
                onTap: () => _navigateTo(MedicineHistory(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),


              DrawerMenuItem(
                icon: Icons.location_on,
                title: 'Track Ambulance',
                onTap: () => _navigateTo(TrackAmbulance(
                  email: widget.email,
                  name: widget.name,
                  mobile: widget.mobile,
                  pkey: widget.pkey,
                )),
              ),


            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background color gradient
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.lightBlue[50]!, Colors.lightGreen[50]!],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          // Centered Text
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.health_and_safety,
                    size: 100,
                    color: Colors.lightBlue[800],
                  ),
                  SizedBox(height: 16),
                  Text(
                    '“Welcome Book Doctor Appointments”',
                    style: TextStyle(
                      fontSize: 26,
                      color: Colors.lightBlue[900],
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          blurRadius: 6.0,
                          color: Colors.black26,
                          offset: Offset(2.0, 2.0),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateTo(Widget page) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }
}

class DrawerMenuItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const DrawerMenuItem({
    Key? key,
    required this.icon,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.lightBlue[800]),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          color: Colors.lightBlue[900],
        ),
      ),
      onTap: onTap,
    );
  }
}
