import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:async';

import 'buymedicine.dart';
import 'welcomescre.dart'; // Your patient home screen
import 'bookappointments.dart'; // The appointment booking screen

class ViewPharmacy extends StatefulWidget {
  final String? name;
  final String? email;
  final String? mobile;
  final String? pkey;

  const ViewPharmacy({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.pkey,
  }) : super(key: key);

  @override
  _PharmacyListViewState createState() => _PharmacyListViewState();
}

class _PharmacyListViewState extends State<ViewPharmacy> {
  late StreamController<DatabaseEvent> _pharmacyStreamController;
  final DatabaseReference _pharmacyRef = FirebaseDatabase.instance.ref('pharmacy');
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    _pharmacyStreamController = StreamController<DatabaseEvent>();
    _pharmacyRef.onValue.listen((event) {
      _pharmacyStreamController.add(event);
    });
  }

  @override
  void dispose() {
    _pharmacyStreamController.close();
    super.dispose();
  }

  Widget _buildPharmacyListView() {
    return StreamBuilder<DatabaseEvent>(
      stream: _pharmacyStreamController.stream,
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data?.snapshot.value != null) {
          Map<String, dynamic> data = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
          List<Map<String, dynamic>> filteredPharmacies = data.entries
              .map((entry) => Map<String, dynamic>.from(entry.value))
              .where((pharmacy) {
            if (searchQuery.isNotEmpty) {
              return pharmacy['pharmacyName']
                  ?.toString()
                  .toLowerCase()
                  .contains(searchQuery.toLowerCase()) ??
                  false;
            }
            return true;
          }).toList();

          if (filteredPharmacies.isEmpty) {
            return Center(
              child: Text(
                'No pharmacies found',
                style: TextStyle(
                  color: Colors.purple[800],
                  fontSize: 16,
                ),
              ),
            );
          }

          return Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/book.jpg',
                  fit: BoxFit.cover,
                  color: Colors.purple.withOpacity(0.1),
                  colorBlendMode: BlendMode.lighten,
                ),
              ),
              ListView.builder(
                itemCount: filteredPharmacies.length,
                itemBuilder: (context, index) {
                  final pharmacy = filteredPharmacies[index];
                  final String pharmacyKey = pharmacy['ukey'] ?? '';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0),
                    ),
                    margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                    elevation: 6,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16.0),
                        gradient: LinearGradient(
                          colors: [Colors.purple[400]!, Colors.deepPurpleAccent],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: ListTile(
                        leading: pharmacy['photoUrl'] != null
                            ? CircleAvatar(
                          backgroundImage: NetworkImage(pharmacy['photoUrl']),
                          radius: 40,
                        )
                            : Icon(
                          Icons.local_pharmacy,
                          size: 50,
                          color: Colors.white,
                        ),
                        title: Text(
                          pharmacy['pharname'] ?? 'Unknown',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'E-Mail: ${pharmacy['pharemail'] ?? 'Unknown'}',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,
                              ),
                            ),
                            Text(
                              'Contact: ${pharmacy['pharcontact'] ?? 'Unknown'}',
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.white70,
                              ),
                            ),
                            SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => BuyMedicine(
                                      email: widget.email,
                                      name: widget.name,
                                      mobile: widget.mobile,
                                      pkey: widget.pkey,
                                      doctorKey: pharmacyKey,
                                      doctorName: pharmacy['pharname'],
                                      doctorfee: pharmacy['pharemail'],
                                      specialist: pharmacy['pharcontact'],
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepPurple[800],
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text('Buy Medicine'),
                            ),
                          ],
                        ),
                        isThreeLine: true,
                      ),
                    ),
                  );
                },
              ),
            ],
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error: ${snapshot.error}',
              style: TextStyle(color: Colors.red),
            ),
          );
        } else {
          return Center(child: CircularProgressIndicator());
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => PatientHome(
              email: widget.email,
              name: widget.name,
              mobile: widget.mobile,
              pkey: widget.pkey,
            ),
          ),
        );
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepPurple[800],
          title: Center(
            child: Text(
              'Pharmacy List',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Enter pharmacy name',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    searchQuery = value;
                  });
                },
              ),
            ),
            Expanded(child: _buildPharmacyListView()),
          ],
        ),
      ),
    );
  }
}
