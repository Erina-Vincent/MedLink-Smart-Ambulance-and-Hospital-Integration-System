import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../firebase_options.dart'; // Adjust import paths as per your project structure
import '../services/auth_services.dart';
import '../utils/appvalidator.dart';
import 'doctorlog.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MaterialApp(
    home: DoctorRegister(),
  ));
}

class DoctorRegister extends StatefulWidget {
  DoctorRegister({Key? key}) : super(key: key);

  @override
  State<DoctorRegister> createState() => _SignUpViewState();
}

class _SignUpViewState extends State<DoctorRegister> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  TextEditingController namecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  TextEditingController locationcontroller = TextEditingController();
  TextEditingController mobilecontroller = TextEditingController();

  var isLoader = false;
  var authservice = AuthService();
  var appvalidator = AppValidator();

  Future<void> _submitForm() async {
    if (_formkey.currentState?.validate() ?? false) {
      setState(() {
        isLoader = true;
      });
      try {
        final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailcontroller.text,
          password: passwordcontroller.text,
        );

        User? user = _auth.currentUser;
        String? userId = user?.uid;

        Map<String, dynamic> doctorData = {
          'name': namecontroller.text,
          'email': emailcontroller.text,
          'password': passwordcontroller.text,
          'location': locationcontroller.text,
          'mobile': mobilecontroller.text,
          'status': 'request',
          'dockey': userId,
        };
        await sendVerificationEmail();

        await _database.child('doctor').child(userId!).set(doctorData);

        namecontroller.clear();
        emailcontroller.clear();
        passwordcontroller.clear();
        locationcontroller.clear();
        mobilecontroller.clear();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check, color: Colors.white),
                SizedBox(width: 8.0),
                Text('Registered Successfully', style: TextStyle(color: Colors.white)),
              ],
            ),
            backgroundColor: Colors.teal,
            duration: Duration(seconds: 3),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => DoctorLogin()),
        );
      } catch (e) {
        showDialog(context: context, builder: (context) {
          return AlertDialog(
            title: Text("Sign Up Failed"),
            content: Text(e.toString()),
          );
        });
      }

      setState(() {
        isLoader = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => DoctorLogin()),
        );
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal[700]!, Colors.blue[300]!],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 40.0),
            child: SingleChildScrollView(
              child: Form(
                key: _formkey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 80.0),
                    Text(
                      'Create Account',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 60.0),
                    _buildTextFormField(namecontroller, 'Name', Icons.person),
                    SizedBox(height: 20.0),
                    _buildTextFormField(emailcontroller, 'Email', Icons.email, validator: appvalidator.validateEmail),
                    SizedBox(height: 20.0),
                    _buildTextFormField(passwordcontroller, 'Password', Icons.lock, obscureText: true),
                    SizedBox(height: 20.0),
                    _buildTextFormField(locationcontroller, 'Location', Icons.location_on),
                    SizedBox(height: 20.0),
                    _buildTextFormField(mobilecontroller, 'Mobile Number', Icons.phone),
                    SizedBox(height: 40.0),
                    SizedBox(
                      height: 55.0,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          isLoader ? print("Loading") : _submitForm();
                        },
                        child: isLoader
                            ? Center(child: CircularProgressIndicator(color: Colors.deepPurple[600]))
                            : Text('Register', style: TextStyle(fontSize: 20, color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.deepPurple[600],
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30.0),
                    TextButton(
                      onPressed: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => DoctorLogin()));
                      },
                      child: Text(
                        'Already have an account? Login',
                        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(TextEditingController controller, String label, IconData icon, {bool obscureText = false, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      style: TextStyle(color: Colors.white),
      cursorColor: Colors.white,
      obscureText: obscureText,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        fillColor: Colors.white.withOpacity(0.15),
        filled: true,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.white),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.white),
        ),
        labelText: label,
        labelStyle: TextStyle(color: Colors.white.withOpacity(0.9)),
        prefixIcon: Icon(icon, color: Colors.white.withOpacity(0.8)),
      ),
      validator: validator,
    );
  }
}

Future<void> sendVerificationEmail() async {
  User? user = FirebaseAuth.instance.currentUser;
  if (user != null && !user.emailVerified) {
    await user.sendEmailVerification();
    print("Verification email sent to ${user.email}");
  }
}
