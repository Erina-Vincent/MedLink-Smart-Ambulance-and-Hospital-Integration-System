import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:patientmonitor/doctor/viewbookings.dart';
import 'availability.dart';
import 'doctorlog.dart';
import 'myappointments.dart';

void main() {
  runApp(MaterialApp(
    home: DoctorHome(),
  ));
}

class DoctorHome extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? dockey;

  const DoctorHome({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.dockey,
  }) : super(key: key);

  @override
  State<DoctorHome> createState() => _DoctorHomeState();
}

class _DoctorHomeState extends State<DoctorHome> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      HomePage(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        dockey: widget.dockey,

      ),
      AddPage(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        dockey: widget.dockey,
      ),
      ViewBookings(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        dockey: widget.dockey,
      ),
      MyAppointmentsDoctor(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        dockey: widget.dockey,
      ),


    ];

    var isLogoutLoading = false;

    Future<void> logout() async {
      setState(() {
        isLogoutLoading = true;
      });

      await FirebaseAuth.instance.signOut();

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => DoctorLogin()),
      );

      setState(() {
        isLogoutLoading = false;
      });
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal[700],
        title: Text('Doctor Dashboard'),
        actions: [
          IconButton(
            onPressed: logout,
            icon: isLogoutLoading
                ? CircularProgressIndicator()
                : Icon(Icons.exit_to_app, color: Colors.white),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(widget.name ?? "Doctor"),
              accountEmail: Text(widget.email ?? "Email"),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Text(
                  widget.name != null
                      ? widget.name![0].toUpperCase()
                      : 'D',
                  style: TextStyle(fontSize: 40.0, color: Colors.teal[700]),
                ),
              ),
              decoration: BoxDecoration(color: Colors.teal[800]),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () {
                setState(() {
                  _selectedIndex = 0;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.add),
              title: Text('Add Details'),
              onTap: () {
                setState(() {
                  _selectedIndex = 1;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.view_agenda),
              title: Text('View Appointments'),
              onTap: () {
                setState(() {
                  _selectedIndex = 2;
                });
                Navigator.pop(context);
              },
            ),

            ListTile(
              leading: Icon(Icons.chat),
              title: Text('My Appointments'),
              onTap: () {
                setState(() {
                  _selectedIndex = 3;
                });
                Navigator.pop(context);
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.exit_to_app),
              title: Text('Logout'),
              onTap: logout,
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
    );
  }
}

// Home Page
class HomePage extends StatelessWidget {

  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? dockey;

  const HomePage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.dockey,
  }) : super(key: key);







  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/homedoc.jpg'), // Replace with your image path
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Welcome to the Doctor Dashboard',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Text(
                  'Here you can manage your appointments, patients, and more.',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Add Page for entering doctor details

// Placeholder for Chat Page

