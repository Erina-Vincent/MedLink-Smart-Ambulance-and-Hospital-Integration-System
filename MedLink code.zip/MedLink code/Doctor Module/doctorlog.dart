import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import '../firebase_options.dart';
import '../main.dart';
import '../services/auth_services.dart';
import '../utils/appvalidator.dart';
import 'doctorreg.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MaterialApp(
    home: DoctorLogin(),
  ));
}

class DoctorLogin extends StatefulWidget {
  DoctorLogin({Key? key}) : super(key: key);

  @override
  _DoctorLoginState createState() => _DoctorLoginState();
}

class _DoctorLoginState extends State<DoctorLogin> {
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final emailcontroller = TextEditingController();
  final passwordcontroller = TextEditingController();
  var isLoader = false;
  var authservice = AuthService();
  var appvalidator = AppValidator();

  Future<void> _submitform() async {
    setState(() {
      isLoader = true;
    });

    var data = {
      "email": emailcontroller.text,
      "password": passwordcontroller.text,
    };

    await authservice.doctorlogin(data, context);

    setState(() {
      isLoader = false;
    });
  }

  InputDecoration _buildInputDecoration(String label, IconData prefixIcon) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: Colors.teal[400]),
      prefixIcon: Icon(prefixIcon, color: Colors.deepPurple[600]),
      filled: true,
      fillColor: Colors.grey[100],
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16.0),
        borderSide: BorderSide(color: Colors.teal[300]!),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16.0),
        borderSide: BorderSide(color: Colors.deepPurple[600]!),
      ),
      contentPadding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
    );
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => SplashScreen()),
    );
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: Stack(
          children: [
            // Background gradient
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.teal[700]!, Colors.blue[300]!],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
            Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo or Image
                      Image.asset(
                        'assets/images/doctorlog.png', // Update with your logo or image
                        height: 120,
                      ),
                      const SizedBox(height: 40),

                      // Title
                      Text(
                        'Doctor Login',
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          fontFamily: 'Roboto',
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Email Input
                      TextFormField(
                        controller: emailcontroller,
                        style: TextStyle(color: Colors.teal[900]),
                        cursorColor: Colors.teal,
                        keyboardType: TextInputType.emailAddress,
                        decoration: _buildInputDecoration('Email', Icons.email),
                        validator: appvalidator.validateEmail,
                      ),
                      const SizedBox(height: 20),

                      // Password Input
                      TextFormField(
                        controller: passwordcontroller,
                        style: TextStyle(color: Colors.teal[900]),
                        cursorColor: Colors.teal,
                        keyboardType: TextInputType.visiblePassword,
                        decoration: _buildInputDecoration('Password', Icons.lock),
                        obscureText: true,
                        validator: appvalidator.validatepassword,
                      ),
                      const SizedBox(height: 30),

                      // Login Button
                      SizedBox(
                        height: 55.0,
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            isLoader ? print("Loading") : _submitform();
                          },
                          child: isLoader
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text(
                            'Login',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          style: ElevatedButton.styleFrom(
                            primary: Colors.deepPurple[600],
                            onPrimary: Colors.white,
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),

                      // Divider with "or"
                      Row(
                        children: [
                          Expanded(
                            child: Divider(color: Colors.teal[200], thickness: 1),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: Text(
                              'Or',
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                            ),
                          ),
                          Expanded(
                            child: Divider(color: Colors.teal[200], thickness: 1),
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // Register Option
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Don't have an account?",
                            style: TextStyle(color: Colors.white),
                          ),
                          const SizedBox(width: 5),
                          GestureDetector(
                            onTap: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DoctorRegister(),
                                ),
                              );
                            },
                            child: Text(
                              'Register Now',
                              style: TextStyle(
                                color: Colors.deepPurple[600],
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
