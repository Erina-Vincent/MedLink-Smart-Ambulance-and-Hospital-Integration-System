import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'doctorhome.dart';
import 'chat.dart';
import 'patientdocumentspage.dart';

class MyAppointmentsDoctor extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? usertype;
  final String? mobile;
  final String? dockey;

  const MyAppointmentsDoctor({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.usertype,
    this.mobile,
    this.dockey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<MyAppointmentsDoctor> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('appointments');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('doctorKey')
          .equalTo(widget.dockey)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'confirmed')
              .map((entry) {
            return {
              'key': entry.key,
              'patientName': entry.value['patientName'] ?? 'Unknown',
              'patientEmail': entry.value['patientEmail'] ?? 'Unknown',
              'patientMobile': entry.value['patientMobile'] ?? 'Unknown',
              'appointmentTime': entry.value['appointmentTime'] ?? 'Unknown',
              'status': entry.value['status'] ?? 'Unknown',
              'patientKey': entry.value['uKey'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DoctorHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          dockey: widget.dockey,
        ),
      ),
    );
    return true;
  }

  void _navigateToChat(String? patientKey) {
    if (patientKey != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => DoctorChatPage(
            dockey: widget.dockey,
            ukey: patientKey,
          ),
        ),
      );
    } else {
      _showErrorDialog('Patient key is missing.');
    }
  }

  void _navigateToPatientDocuments(String? patientKey) {
    if (patientKey != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PatientDocumentsPage(
            dockey: widget.dockey,
            ukey: patientKey,
          ),
        ),
      );
    } else {
      _showErrorDialog('Patient key is missing.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(

        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.event_available,
                            size: 40, color: Colors.blue[700]),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['patientName']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['patientEmail']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['patientMobile']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] ==
                                      'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.chat),
                          color: Colors.teal,
                          onPressed: () => _navigateToChat(
                              appointment['patientKey']),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        ElevatedButton(
                          onPressed: () => _navigateToPatientDocuments(
                              appointment['patientKey']),
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blueAccent,
                          ),
                          child: const Text('View Documents'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
