import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'doctorhome.dart';

class ViewBookings extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? dockey;

  const ViewBookings({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.dockey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<ViewBookings> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('appointments');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('doctorKey')
          .equalTo(widget.dockey) // Query appointments by the user's key
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        // Filter for appointments with status 'request'
        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'request') // Include this filter
              .map((entry) {
            return {
              'key': entry.key,
              'patientName': entry.value['patientName'],
              'patientEmail': entry.value['patientEmail'],
              'patientMobile': entry.value['patientMobile'],
              'appointmentTime': entry.value['appointmentTime'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      // Handle any errors during fetching
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DoctorHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          dockey: widget.dockey,
        ),
      ),
    );
    return true; // Return true to allow pop
  }

  void _acceptAppointment(String appointmentKey) async {
    try {
      // Update appointment status to 'accepted'
      await _appointmentsRef.child(appointmentKey).update({
        'status': 'confirmed', // Change status to 'accepted'
      });

      // After updating, redirect to the home page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DoctorHome(
            email: widget.email,
            name: widget.name,
            location: widget.location,
            mobile: widget.mobile,
            dockey: widget.dockey,
          ),
        ),
      );
    } catch (e) {
      // Handle any errors during the update
      print('Error updating appointment: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(

        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.event_available, size: 40, color: Colors.blue[700]),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['patientName']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['patientEmail']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['patientMobile']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: ElevatedButton(
                        onPressed: () {
                          // Accept the appointment
                          _acceptAppointment(appointment['key']);
                        },
                        child: Text('Accept'),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green, // Change this as needed
                          onPrimary: Colors.white,
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
