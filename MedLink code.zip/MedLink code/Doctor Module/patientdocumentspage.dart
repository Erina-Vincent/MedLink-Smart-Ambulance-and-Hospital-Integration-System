import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:patientmonitor/patient/welcomescre.dart';
import 'package:url_launcher/url_launcher.dart';

import 'doctorhome.dart';

class PatientDocumentsPage extends StatefulWidget {
  final String? ukey;
  final String? dockey;
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;

  const PatientDocumentsPage({
    Key? key,
    this.ukey,
    this.dockey,
    this.name,
    this.email,
    this.location,
    this.mobile,

  }) : super(key: key);

  @override
  _HealthcareDocumentsPageState createState() =>
      _HealthcareDocumentsPageState();
}

class _HealthcareDocumentsPageState extends State<PatientDocumentsPage> {
  late DatabaseReference _dbRef;
  List<Map<String, dynamic>> _documents = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _dbRef = FirebaseDatabase.instance.ref('healthcare_documents');
    _fetchDocuments();
  }

  Future<void> _fetchDocuments() async {
    try {
      final snapshot = await _dbRef.get();
      if (snapshot.exists) {
        List<Map<String, dynamic>> documents = [];
        Map<String, dynamic> data =
        Map<String, dynamic>.from(snapshot.value as Map);
        data.forEach((key, value) {
          if (value['uKey'] == widget.ukey) {
            documents.add({
              'key': key,
              ...Map<String, dynamic>.from(value),
            });
          }
        });
        setState(() {
          _documents = documents;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error fetching documents: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DoctorHome(
          email: widget.email,
          name: widget.name,
          mobile: widget.mobile,
          dockey: widget.dockey,
        ),
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Healthcare Documents',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.teal,
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _documents.isEmpty
            ? const Center(
          child: Text(
            'No documents found',
            style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.w500),
          ),
        )
            : ListView.builder(
          itemCount: _documents.length,
          itemBuilder: (context, index) {
            final document = _documents[index];
            return Card(
              elevation: 5,
              margin: const EdgeInsets.symmetric(
                  vertical: 10.0, horizontal: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      document['title'] ?? 'Untitled',
                      style: const TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      document['description'] ?? 'No description available',
                      style: const TextStyle(fontSize: 14.0),
                    ),
                   /* const SizedBox(height: 12.0),
                    ElevatedButton(
                      onPressed: () => _openDocument(document['fileUrl']),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      child: const Text(
                        'View Document',
                        style: TextStyle(
                            fontSize: 16.0, fontWeight: FontWeight.w500),
                      ),
                    ),*/
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _openDocument(String? fileUrl) async {
    if (fileUrl == null || fileUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invalid file URL')),
      );
      return;
    }
    try {
      final Uri url = Uri.parse(fileUrl);
      if (await canLaunchUrl(url)) {
        await launchUrl(url);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cannot open document')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening document: $e')),
      );
    }
  }
}
