import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_database/firebase_database.dart';
import 'doctorhome.dart';

class AddPage extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? dockey;

  const AddPage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.dockey,
  }) : super(key: key);

  @override
  _AddPageState createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {
  final _formKey = GlobalKey<FormState>();
  final _database = FirebaseDatabase.instance.reference();
  bool isLoader = false;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController contactController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController specialistController = TextEditingController();
  TextEditingController hospitalController = TextEditingController();
  TextEditingController timeAvailableController = TextEditingController();
  TextEditingController feeController = TextEditingController();
  TextEditingController aboutController = TextEditingController();

  @override
  void initState() {
    super.initState();
    nameController.text = widget.name ?? '';
    emailController.text = widget.email ?? '';
    contactController.text = widget.mobile ?? '';
    locationController.text = widget.location ?? '';

    // Set up system chrome for full-screen gradient
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    );
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoader = true;
      });

      try {
        String userId = widget.dockey ?? 'dummyUserId';

        Map<String, dynamic> userData = {
          'name': nameController.text,
          'email': emailController.text,
          'contact': contactController.text,
          'location': locationController.text,
          'specialist': specialistController.text,
          'hospital': hospitalController.text,
          'avail': timeAvailableController.text,
          'fees': feeController.text,
          'about': aboutController.text,
          'ukey': userId,
        };

        await _database.child('doctorinfo').child(userId).set(userData);

        nameController.clear();
        emailController.clear();
        contactController.clear();
        locationController.clear();
        specialistController.clear();
        hospitalController.clear();
        timeAvailableController.clear();
        feeController.clear();
        aboutController.clear();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Details Updated Successfully'),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => DoctorHome(
              email: widget.email,
              name: widget.name,
              location: widget.location,
              mobile: widget.mobile,
              dockey: widget.dockey,
            ),
          ),
        );
      } catch (e) {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Update Failed"),
              content: Text(e.toString()),
            );
          },
        );
      } finally {
        setState(() {
          isLoader = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        body: Stack(
          children: [
            // Full-screen gradient background
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green, Colors.white],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            // SafeArea content
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Card(
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              children: [
                                _buildTextFormField('Name', nameController),
                                SizedBox(height: 15),
                                _buildTextFormField('Email', emailController),
                                SizedBox(height: 15),
                                _buildTextFormField('Contact', contactController),
                                SizedBox(height: 15),
                                _buildTextFormField('Location', locationController),
                                SizedBox(height: 15),
                                _buildTextFormField('Specialist', specialistController),
                                SizedBox(height: 15),
                                _buildTextFormField('Hospital Name', hospitalController),
                                SizedBox(height: 15),
                                _buildTextFormField('Availability', timeAvailableController),
                                SizedBox(height: 15),
                                _buildTextFormField('Consultant Fee', feeController),
                                SizedBox(height: 15),
                                _buildTextFormField('About', aboutController),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _submitForm,
          label: isLoader
              ? CircularProgressIndicator(color: Colors.white)
              : Text('Submit'),
          icon: Icon(Icons.check),
          backgroundColor: Colors.teal,
        ),
      ),
    );
  }

  Widget _buildTextFormField(String label, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: BorderSide.none,
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
    );
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => DoctorHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          dockey: widget.dockey,
        ),
      ),
    );
    return true;
  }

}
