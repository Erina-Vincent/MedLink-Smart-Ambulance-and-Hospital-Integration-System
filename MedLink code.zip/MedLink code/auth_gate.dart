

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

import '../ambulance/ambhome.dart';
import '../ambulance/amblog.dart';
import '../patient/uslogin.dart';
import '../patient/welcomescre.dart';


void main() {
  runApp(new MaterialApp(
    home: new AuthGate(),



  ));




}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});


  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context,snapshot){
          if(!snapshot.hasData) {
            return AmbulanceLogin(





            );


          }else{
            User? user = snapshot.data;
            String uid = user?.uid ?? ''; // You can use the UID as ne

            DatabaseReference databaseReference = FirebaseDatabase.instance.reference().child('ambulance').child(uid);

            // Use the onValue stream to listen for changes
            databaseReference.onValue.listen((event) {
              print('Database event received: $event');

              // Check if the event contains the data you need
              if (event.snapshot != null && event.snapshot.value != null) {
                var userData = event.snapshot.value;
                print('User data from database: $userData');

                // Check if userData is a Map
                if (userData is Map<Object?, Object?>) {
                  // Cast the map to Map<String, dynamic>
                  Map<String, dynamic> userDataMap = userData.cast<String, dynamic>();

                  // Access email directly and handle null case

                  String? email = userDataMap['email'];
                  String? name = userDataMap['name'];
                  String? mobile = userDataMap['mobile'];

                  String? ambkey = userDataMap['ambkey'];


                  if (email != null) {
                    print('Email from database: $email');

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Login Successfully')),
                    );

                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => AmbulanceHome(



                            name: name,
                            email: email,

                            mobile:mobile,

                            ambkey: ambkey


                        ))
                    );
                  } else {
                    print('Email key is null or not found in userData.');
                  }
                } else {
                  print('Invalid data structure in the database.');
                  print('Type of userData: ${userData.runtimeType}');
                  print('Content of userData: $userData');
                }
              }
            });


          }


          return AmbulanceHome();
        }

    );

  }
}








