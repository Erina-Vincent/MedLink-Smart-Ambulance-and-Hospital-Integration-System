import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import 'hospitalhome.dart';




void main() {
  runApp(const MaterialApp(
    home: PharmacyPage(),
  ));
}

class PharmacyPage extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const PharmacyPage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  State<PharmacyPage> createState() => _AmbulanceHomeState();
}

class _AmbulanceHomeState extends State<PharmacyPage> {
  int _selectedIndex = 0;
  bool isLogoutLoading = false;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomePage(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),
      PharmacyInfo(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),
      Orders(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,



      ),
      Deliveries(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,


      ),
    ];
  }


  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          'Pharmacy Dashboard',
          style: TextStyle(color: Colors.teal),
        ),

      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'Add Info',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shop),
            label: 'Orders',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.receipt),
            label: 'Deliveries',
          ),
        ],
      ),
    );
  }
}

// Home Page
class HomePage extends StatelessWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const HomePage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/preg.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  'Welcome to the Pharmacy Dashboard',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Text(
                  'Medications can save lives, but only when used properly under the guidance of a pharmacist.',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class PharmacyInfo extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const PharmacyInfo({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _AddPageState createState() => _AddPageState();
}

class _AddPageState extends State<PharmacyInfo> {
  final _formKey = GlobalKey<FormState>();
  final _database = FirebaseDatabase.instance.reference();
  bool isLoader = false;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController contactController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoader = true;
      });

      try {
        FirebaseAuth _auth = FirebaseAuth.instance;
        User? user = _auth.currentUser;
        String? userId = user?.uid;

        if (userId == null) {
          throw Exception("User ID not found. Please log in again.");
        }

        DatabaseReference _database = FirebaseDatabase.instance.reference();

        Map<String, dynamic> userData = {
          'pharname': nameController.text,
          'pharemail': emailController.text,
          'pharcontact': contactController.text,
          'ukey': userId, // Store user ID in 'ukey'
        };

        await _database.child('pharmacy').child(userId).set(userData);

        // Clear input fields
        nameController.clear();
        emailController.clear();
        contactController.clear();

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Details Updated Successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } catch (e) {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Update Failed"),
              content: Text(e.toString()),
            );
          },
        );
      } finally {
        setState(() {
          isLoader = false;
        });
      }
    }
  }


  Future<bool> _onWillPop() async {
    return Future.value(true);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal.shade700, Colors.teal.shade400],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Card(
                      elevation: 12,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      color: Colors.white.withOpacity(0.9),
                      child: Padding(
                        padding: const EdgeInsets.all(30.0),
                        child: Column(
                          children: [
                            _buildTextFormField('Pharmacy Name', nameController),
                            _buildTextFormField('E-Mail', emailController),
                            _buildTextFormField('Contact', contactController),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    isLoader
                        ? Center(child: CircularProgressIndicator())
                        : _buildButton('Submit', _submitForm),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.teal, fontSize: 16),
          hintText: 'Enter $label',
          hintStyle: TextStyle(color: Colors.grey.shade600),
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.teal, width: 2.0),
            borderRadius: BorderRadius.circular(25),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.teal, width: 1.5),
            borderRadius: BorderRadius.circular(25),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $label';
          }
          return null;
        },
      ),
    );
  }

  Widget _buildButton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(
        text,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(vertical: 15),
        primary: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        elevation: 5,
        shadowColor: Colors.blueAccent.withOpacity(0.6),
      ),
    );
  }
}



class Orders extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const Orders({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<Orders> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('medicine');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hoskey')
          .equalTo(widget.hoskey) // Query appointments by the user's key
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        // Filter for appointments with status 'request'
        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'request') // Include this filter
              .map((entry) {
            return {
              'key': entry.key,
              'patientName': entry.value['patientName'],
              'patientEmail': entry.value['patientEmail'],
              'patientMobile': entry.value['patientMobile'],
              'appointmentTime': entry.value['appointmentTime'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      // Handle any errors during fetching
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => HospitalHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          hoskey: widget.hoskey,
        ),
      ),
    );
    return true; // Return true to allow pop
  }

  void _acceptAppointment(String appointmentKey) async {
    try {
      // Update appointment status to 'accepted'
      await _appointmentsRef.child(appointmentKey).update({
        'status': 'confirmed', // Change status to 'accepted'
      });

      // After updating, redirect to the home page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HospitalHome(
            email: widget.email,
            name: widget.name,
            location: widget.location,
            mobile: widget.mobile,
            hoskey: widget.hoskey,
          ),
        ),
      );
    } catch (e) {
      // Handle any errors during the update
      print('Error updating appointment: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(

        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.event_available, size: 40, color: Colors.blue[700]),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['patientName']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['patientEmail']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['patientMobile']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: ElevatedButton(
                        onPressed: () {
                          // Accept the appointment
                          _acceptAppointment(appointment['key']);
                        },
                        child: Text('Accept'),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green, // Change this as needed
                          onPrimary: Colors.white,
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}


// Near By Hospital Page
class Deliveries extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? usertype;
  final String? mobile;
  final String? hoskey;

  const Deliveries({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.usertype,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyDeliverisState createState() => _MyDeliverisState();
}

class _MyDeliverisState extends State<Deliveries> {
  List<Map<dynamic, dynamic>> _Deliveries = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('medicine');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hoskey')
          .equalTo(widget.hoskey)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _Deliveries = data.entries
              .where((entry) => entry.value['status'] == 'confirmed')
              .map((entry) {
            return {
              'key': entry.key,
              'patientName': entry.value['patientName'] ?? 'Unknown',
              'patientEmail': entry.value['patientEmail'] ?? 'Unknown',
              'patientMobile': entry.value['patientMobile'] ?? 'Unknown',
              'appointmentTime': entry.value['appointmentTime'] ?? 'Unknown',
              'status': entry.value['status'] ?? 'Unknown',
              'patientKey': entry.value['uKey'], // Ensure patientKey is valid
            };
          }).toList();
        });
      } else {
        setState(() {
          _Deliveries = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => HospitalHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          hoskey: widget.hoskey,
        ),
      ),
    );
    return true;
  }



  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(

        body: _Deliveries.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _Deliveries.length,
          itemBuilder: (context, index) {
            final appointment = _Deliveries[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.event_available,
                            size: 40, color: Colors.blue[700]),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['patientName']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['patientEmail']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['patientMobile']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] ==
                                      'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),

                      ],
                    ),

                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
