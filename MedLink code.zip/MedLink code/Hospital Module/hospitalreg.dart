import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../firebase_options.dart';
import '../services/auth_services.dart';
import '../utils/appvalidator.dart';
import 'hospitalhome.dart'; // Hospital home page
import 'hospitallog.dart'; // Hospital login page

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MaterialApp(
    home: AuthGate(),
  ));
}

class AuthGate extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasData && snapshot.data!.emailVerified) {
          return HospitalHome(); // Navigate to the home page if logged in and email is verified
        }

        return HospitalLogin(); // Navigate to the login page otherwise
      },
    );
  }
}

class HospitalRegister extends StatefulWidget {
  @override
  State<HospitalRegister> createState() => _HospitalRegisterState();
}

class _HospitalRegisterState extends State<HospitalRegister> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.ref();
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController latitudeController = TextEditingController();
  TextEditingController longitudeController = TextEditingController();

  var isLoader = false;
  var authService = AuthService();
  var appValidator = AppValidator();

  Future<void> _getCurrentLocation() async {
    LocationPermission permission = await Geolocator.requestPermission();

    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Location permission is required to get the current location."),
        backgroundColor: Colors.red,
      ));
    } else {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      setState(() {
        latitudeController.text = position.latitude.toString();
        longitudeController.text = position.longitude.toString();
      });
    }
  }

  Future<void> _submitForm() async {
    if (_formkey.currentState?.validate() ?? false) {
      setState(() {
        isLoader = true;
      });

      try {
        final credential = await _auth.createUserWithEmailAndPassword(
          email: emailController.text,
          password: passwordController.text,
        );

        User? user = _auth.currentUser;
        String? userId = user?.uid;

        Map<String, dynamic> hospitalData = {
          'name': nameController.text,
          'email': emailController.text,
          'password': passwordController.text,
          'location': locationController.text,
          'mobile': mobileController.text,
          'latitude': latitudeController.text,
          'longitude': longitudeController.text,
          'status': 'request',
          'hoskey': userId,
        };

        await sendVerificationEmail();

        await _database.child('hospital').child(userId!).set(hospitalData);

        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(
            children: [
              Icon(Icons.check, color: Colors.white),
              SizedBox(width: 8.0),
              Text('Registered Successfully', style: TextStyle(color: Colors.white)),
            ],
          ),
          backgroundColor: Colors.teal,
          duration: Duration(seconds: 3),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
        ));

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HospitalLogin()),
        );
      } catch (e) {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Sign Up Failed"),
              content: Text(e.toString()),
            );
          },
        );
      }

      setState(() {
        isLoader = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => true,
      child: Scaffold(
        backgroundColor: Color(0xFF003366),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 40.0),
            child: SingleChildScrollView(
              child: Form(
                key: _formkey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 80.0),
                    Text(
                      'Create Account',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 60.0),
                    _buildTextFormField(nameController, 'Name', Icons.person),
                    SizedBox(height: 20.0),
                    _buildTextFormField(emailController, 'Email', Icons.email, validator: appValidator.validateEmail),
                    SizedBox(height: 20.0),
                    _buildTextFormField(passwordController, 'Password', Icons.lock, obscureText: true),
                    SizedBox(height: 20.0),
                    _buildTextFormField(locationController, 'Location', Icons.location_on),
                    SizedBox(height: 20.0),
                    _buildTextFormField(mobileController, 'Mobile Number', Icons.phone),
                    SizedBox(height: 20.0),
                    _buildTextFormField(latitudeController, 'Latitude', Icons.location_searching_outlined),
                    SizedBox(height: 20.0),
                    _buildTextFormField(longitudeController, 'Longitude', Icons.location_searching_outlined),

                    SizedBox(height: 40.0),
                    SizedBox(
                      height: 55.0,
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          isLoader ? null : _submitForm();
                        },
                        child: isLoader
                            ? Center(child: CircularProgressIndicator(color: Colors.green))
                            : Text('Register', style: TextStyle(fontSize: 20, color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green,
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30.0),
                    TextButton(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => HospitalLogin()),
                        );
                      },
                      child: Text(
                        'Already have an account? Login',
                        style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 16),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: _getCurrentLocation,
                      child: Text('Get Current Location'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField(TextEditingController controller, String label, IconData icon, {bool obscureText = false, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      style: TextStyle(color: Colors.white),
      cursorColor: Colors.white,
      obscureText: obscureText,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        fillColor: Colors.white.withOpacity(0.15),
        filled: true,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.white),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20.0),
          borderSide: BorderSide(color: Colors.white),
        ),
        labelText: label,
        labelStyle: TextStyle(color: Colors.white.withOpacity(0.9)),
        prefixIcon: Icon(icon, color: Colors.white.withOpacity(0.8)),
      ),
      validator: validator,
    );
  }
}

Future<void> sendVerificationEmail() async {
  User? user = FirebaseAuth.instance.currentUser;
  if (user != null && !user.emailVerified) {
    await user.sendEmailVerification();
    print("Verification email sent to \${user.email}");
  }
}