import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:url_launcher/url_launcher.dart';

class LiveLoc extends StatefulWidget {
  final String rkey;

  LiveLoc({required this.rkey});

  @override
  _LiveLocationPageState createState() => _LiveLocationPageState();
}

class _LiveLocationPageState extends State<LiveLoc> {
  String _currentLocation = "Fetching location...";
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  double? latitude;
  double? longitude;

  @override
  void initState() {
    super.initState();
    _fetchLocationFromFirebase();
  }

  // Fetch location from Firebase and update the UI
  Future<void> _fetchLocationFromFirebase() async {
    _database.child('locations').child(widget.rkey).once().then((DatabaseEvent snapshot) {
      if (snapshot.snapshot.value != null) {
        var data = snapshot.snapshot.value as Map<dynamic, dynamic>;
        setState(() {
          latitude = double.tryParse(data['latitude']?.toString() ?? '');
          longitude = double.tryParse(data['longitude']?.toString() ?? '');
          _currentLocation =
          'Latitude: $latitude, Longitude: $longitude'; // Update with fetched location
        });
      } else {
        setState(() {
          _currentLocation = "No location data available.";
        });
      }
    });
  }

  // Method to launch Google Maps with the latitude and longitude
  Future<void> _openInGoogleMaps() async {
    if (latitude != null && longitude != null) {
      final url =
          'https://www.google.com/maps?q=$latitude,$longitude'; // Open in Google Maps
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not open Google Maps';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Live Location"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.location_on,
              size: 50,
              color: Colors.red,
            ),
            SizedBox(height: 20),
            Text(
              _currentLocation,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _openInGoogleMaps,
              child: Text("Open in Google Maps"),
            ),
          ],
        ),
      ),
    );
  }
}
