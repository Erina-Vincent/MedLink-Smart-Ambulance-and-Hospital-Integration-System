/*
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:patientmonitor/hospital/pharmacy.dart';
import 'hospitallog.dart';

void main() {
  runApp(MaterialApp(
    home: HospitalHome(),
  ));
}

class HospitalHome extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const HospitalHome({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  State<HospitalHome> createState() => _HospitalHomeState();
}

class _HospitalHomeState extends State<HospitalHome> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      EmergencyAlerts(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),
      HomePage(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),
      Track(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),
    ];

    var isLogoutLoading = false;

    Future<void> logout() async {
      setState(() {
        isLogoutLoading = true;
      });

      await FirebaseAuth.instance.signOut();

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HospitalLogin()),
      );

      setState(() {
        isLogoutLoading = false;
      });
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('Hospital Dashboard'),
        actions: [
          IconButton(
            onPressed: logout,
            icon: isLogoutLoading
                ? CircularProgressIndicator(color: Colors.white)
                : Icon(Icons.exit_to_app, color: Colors.red),
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        selectedItemColor: Colors.blueGrey,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.white,
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.emergency,
              color: Colors.red,
            ),
            label: 'Emergencies',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.receipt,
              color: Colors.black,
            ),
            label: 'Records',
          ),
        ],
      ),
    );
  }
}

class EmergencyAlerts extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const EmergencyAlerts({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<EmergencyAlerts> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef = FirebaseDatabase.instance.ref('EmergencyAlerts');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hoskey')
          .equalTo(widget.hoskey) // Query appointments by the user's hoskey
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        // Filter for appointments with status 'request'
        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'request')
              .map((entry) {
            return {
              'key': entry.key,
              'ambname': entry.value['ambname'],
              'ambemail': entry.value['ambemail'],
              'ambmobile': entry.value['ambmobile'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => HospitalHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          hoskey: widget.hoskey,
        ),
      ),
    );
    return true;
  }

  void _acceptAppointment(String appointmentKey) async {
    try {
      await _appointmentsRef.child(appointmentKey).update({
        'status': 'confirmed',
      });

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HospitalHome(
            email: widget.email,
            name: widget.name,
            location: widget.location,
            mobile: widget.mobile,
            hoskey: widget.hoskey,
          ),
        ),
      );
    } catch (e) {
      print('Error updating appointment: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.event_available, size: 40, color: Colors.blue[700]),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Tourist: ${appointment['ambname']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['ambemail']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['ambmobile']}',
                                style: TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: ElevatedButton(
                        onPressed: () {
                          _acceptAppointment(appointment['key']);
                        },
                        child: Text('Accept'),
                        style: ElevatedButton.styleFrom(
                          primary: Colors.green,
                          onPrimary: Colors.white,
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }



}
class Track extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const Track({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyTrackState createState() => _MyTrackState();
}

class _MyTrackState extends State<Track> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('Booking');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hoskey')
          .equalTo(widget.hoskey)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'confirmed')
              .map((entry) {
            return {
              'key': entry.key,
              'ambname': entry.value['ambname'],
              'ambemail': entry.value['ambemail'],
              'ambmobile': entry.value['ambmobile'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => HospitalHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          hoskey: widget.hoskey,
        ),
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No appointments found.',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.person, size: 40, color: Colors.blue[700]),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Patient: ${appointment['ambname']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['ambemail']}',
                                style:
                                TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['ambmobile']}',
                                style:
                                TextStyle(fontSize: 16, color: Colors.black87),
                              ),
                              */
/*SizedBox(height: 8),
                              Text(
                                'Time: ${appointment['appointmentTime']}',
                                style: TextStyle(fontSize: 14, color: Colors.black54),
                              ),*//*

                              SizedBox(height: 4),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'confirmed'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
*/
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:patientmonitor/hospital/pharmacy.dart';
import 'package:url_launcher/url_launcher.dart';
import 'hospitallog.dart';

void main() {
  runApp(MaterialApp(
    home: HospitalHome(),
  ));
}

class HospitalHome extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const HospitalHome({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,

    this.hoskey,
  }) : super(key: key);



  @override
  State<HospitalHome> createState() => _HospitalHomeState();
}

class _HospitalHomeState extends State<HospitalHome> {
  int _selectedIndex = 0;



  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [

      EmergencyAlerts(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,


      ),
      HomePage(
        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ),// Placeholder for Add Details Page
      Track(

        name: widget.name,
        email: widget.email,
        location: widget.location,
        mobile: widget.mobile,
        hoskey: widget.hoskey,
      ), // Placeholder for View Appointments Page
      // Placeholder for My Appointments Page
    ];

    var isLogoutLoading = false;
    // print(widget.hoskey);
    Future<void> logout() async {
      setState(() {
        isLogoutLoading = true;
      });

      await FirebaseAuth.instance.signOut();

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => HospitalLogin()),
      );

      setState(() {
        isLogoutLoading = false;
      });
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('Hospital Dashboard'),
        actions: [
          IconButton(
            onPressed: logout,
            icon: isLogoutLoading
                ? CircularProgressIndicator(color: Colors.white)
                : Icon(Icons.exit_to_app, color: Colors.red),
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        selectedItemColor: Colors.blueGrey,
        unselectedItemColor: Colors.grey,
        backgroundColor: Colors.white,
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.emergency,
              color: Colors.red,
            ),
            label: 'Emergencies',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.receipt,
              color: Colors.black,
            ),
            label: 'Records',
          ),
        ],
      ),
    );
  }
}


class EmergencyAlerts extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const EmergencyAlerts({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyAppointmentsState createState() => _MyAppointmentsState();
}

class _MyAppointmentsState extends State<EmergencyAlerts> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('EmergencyAlerts');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hosKey')
          .equalTo(widget.hoskey)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'request')
              .map((entry) {
            return {
              'key': entry.key,
              'patientName': entry.value['ambname'] ?? 'Unknown',
              'patientEmail': entry.value['ambemail'] ?? 'Unknown',
              'patientMobile': entry.value['ambmobile'] ?? 'Unknown',
              'appointmentTime': entry.value['emergencyTime'] ?? 'Unknown',
              'status': entry.value['status'] ?? 'Unknown',
              'patientKey': entry.value['uKey'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<void> _acceptAppointment(String appointmentKey) async {
    try {
      await _appointmentsRef.child(appointmentKey).update({'status': 'accept'});

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Appointment Accepted Successfully!'),
          backgroundColor: Colors.green,
        ),
      );

      _fetchAppointments(); // Refresh the list after accepting
    } catch (e) {
      print('Error accepting appointment: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _appointments.isEmpty
          ? Center(
        child: Text(
          'No Emergencies found.',
          style: TextStyle(fontSize: 18, color: Colors.grey[600]),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _appointments.length,
        itemBuilder: (context, index) {
          final appointment = _appointments[index];
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            elevation: 6,
            margin: const EdgeInsets.only(bottom: 16.0),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.event_available,
                          size: 40, color: Colors.blue[700]),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Patient: ${appointment['patientName']}',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[900],
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'E-mail: ${appointment['patientEmail']}',
                              style: const TextStyle(
                                  fontSize: 16, color: Colors.black87),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Contact: ${appointment['patientMobile']}',
                              style: const TextStyle(
                                  fontSize: 16, color: Colors.black87),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Time: ${appointment['appointmentTime']}',
                              style: const TextStyle(
                                  fontSize: 16, color: Colors.black87),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Status: ${appointment['status']}',
                              style: TextStyle(
                                fontSize: 14,
                                color: appointment['status'] == 'accept'
                                    ? Colors.green
                                    : Colors.orange,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton(
                      onPressed: () =>
                          _acceptAppointment(appointment['key']),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                      child: const Text(
                        'Accept',
                        style:
                        TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const HomePage({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/hoshome.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Welcome to the Hospital Dashboard',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Text(
                  'A hospital is not just a building; it\'s a beacon of hope. ...',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),

                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    // Navigate to PharmacyPage with the necessary data
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PharmacyPage(



                          name: name,
                          email: email,
                          location: location,
                          mobile: mobile,
                          hoskey: hoskey,
                        ),
                      ),
                    );
                  },
                  child: Text('Pharmacy'),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue, // Button color
                    onPrimary: Colors.white, // Text color
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}



class Track extends StatefulWidget {
  final String? name;
  final String? email;
  final String? location;
  final String? mobile;
  final String? hoskey;

  const Track({
    Key? key,
    this.name,
    this.email,
    this.location,
    this.mobile,
    this.hoskey,
  }) : super(key: key);

  @override
  _MyTrackState createState() => _MyTrackState();
}

class _MyTrackState extends State<Track> {
  List<Map<dynamic, dynamic>> _appointments = [];
  final DatabaseReference _appointmentsRef =
  FirebaseDatabase.instance.ref('EmergencyAlerts');

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {

    FirebaseAuth _auth = FirebaseAuth.instance;
    User? user = _auth.currentUser;
    String? userId = user?.uid;
    
    print(userId);
    try {
      final snapshot = await _appointmentsRef
          .orderByChild('hoskey')
          .equalTo(userId)
          .once();

      if (snapshot.snapshot.value != null) {
        final data = snapshot.snapshot.value as Map<dynamic, dynamic>;

        setState(() {
          _appointments = data.entries
              .where((entry) => entry.value['status'] == 'accept')
              .map((entry) {
            return {
              'key': entry.key,
              'ambname': entry.value['ambname'],
              'ambemail': entry.value['ambemail'],
              'ambmobile': entry.value['ambmobile'],
              'ambkey': entry.value['ambkey'],
              'status': entry.value['status'],
            };
          }).toList();
        });
      } else {
        setState(() {
          _appointments = [];
        });
      }
    } catch (e) {
      print('Error fetching appointments: $e');
    }
  }

  Future<bool> _onWillPop() async {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => HospitalHome(
          email: widget.email,
          name: widget.name,
          location: widget.location,
          mobile: widget.mobile,
          hoskey: widget.hoskey,
        ),
      ),
    );
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: _appointments.isEmpty
            ? Center(
          child: Text(
            'No Location is shared currently',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
        )
            : ListView.builder(
          padding: const EdgeInsets.all(16.0),
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 6,
              margin: const EdgeInsets.only(bottom: 16.0),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.person,
                          size: 40,
                          color: Colors.blue[700],
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Ambulance Name: ${appointment['ambname']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[900],
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'E-mail: ${appointment['ambemail']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Contact: ${appointment['ambmobile']}',
                                style: const TextStyle(
                                    fontSize: 16, color: Colors.black87),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Status: ${appointment['status']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: appointment['status'] == 'accept'
                                      ? Colors.green
                                      : Colors.orange,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.map,
                              size: 35, color: Colors.redAccent),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => TrackingPage(
                                  ambKey: appointment['ambkey'],
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}





class TrackingPage extends StatefulWidget {
  final String ambKey;

  TrackingPage({super.key, required this.ambKey});

  @override
  _LiveLocationPageState createState() => _LiveLocationPageState();
}

class _LiveLocationPageState extends State<TrackingPage> {
  String _currentLocation = "Fetching location...";
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  double? latitude;
  double? longitude;

  @override
  void initState() {
    super.initState();
    _fetchLocationFromFirebase();
  }

  // Fetch location from Firebase and update the UI
  Future<void> _fetchLocationFromFirebase() async {
    _database.child('locations').child(widget.ambKey).once().then((DatabaseEvent snapshot) {
      if (snapshot.snapshot.value != null) {
        var data = snapshot.snapshot.value as Map<dynamic, dynamic>;
        setState(() {
          latitude = double.tryParse(data['latitude']?.toString() ?? '');
          longitude = double.tryParse(data['longitude']?.toString() ?? '');
          _currentLocation =
          'Latitude: $latitude, Longitude: $longitude'; // Update with fetched location
        });
      } else {
        setState(() {
          _currentLocation = "No location data available.";
        });
      }
    });
  }

  // Method to launch Google Maps with the latitude and longitude
  Future<void> _openInGoogleMaps() async {
    if (latitude != null && longitude != null) {
      final url =
          'https://www.google.com/maps?q=$latitude,$longitude'; // Open in Google Maps
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not open Google Maps';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Live Location"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.location_on,
              size: 50,
              color: Colors.red,
            ),
            const SizedBox(height: 20),
            Text(
              _currentLocation,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, color: Colors.black),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _openInGoogleMaps,
              child: const Text("Open in Google Maps"),
            ),
          ],
        ),
      ),
    );
  }
}
